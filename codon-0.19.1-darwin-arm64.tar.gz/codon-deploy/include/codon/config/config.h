#pragma once

#define CODON_VERSION       "0.19.1"
#define CODON_VERSION_MAJOR 0
#define CODON_VERSION_MINOR 19
#define CODON_VERSION_PATCH 1
