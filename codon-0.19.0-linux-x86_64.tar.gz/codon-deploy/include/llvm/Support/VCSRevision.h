#define LLVM_REVISION "05ba68c2286e5b1972fb593f316987a07d81ebe1"
#define LLVM_REPOSITORY "https://github.com/exaloop/llvm-project"
